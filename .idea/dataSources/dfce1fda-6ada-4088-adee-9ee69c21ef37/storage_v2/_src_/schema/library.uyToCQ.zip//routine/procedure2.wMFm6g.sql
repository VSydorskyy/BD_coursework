create
  definer = root@localhost procedure procedure2(IN sTitle varchar(255))
BEGIN
    select * from books inner join students on books.reader_id = students.id;
END;

