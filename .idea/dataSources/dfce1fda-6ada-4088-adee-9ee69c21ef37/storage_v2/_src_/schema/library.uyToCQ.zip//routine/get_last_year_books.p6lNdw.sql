create
  definer = root@localhost procedure get_last_year_books()
begin
  select name from books where year(order_date) = 2019;
  select count(name) from books where year(order_date) = 2019;
end;

