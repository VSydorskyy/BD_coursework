create
  definer = root@localhost procedure get_last_month_books()
begin
  select name from books where month(order_date) = 10;
  select count(name) from books where month(order_date) = 10;
end;

