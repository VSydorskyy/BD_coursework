create
  definer = root@localhost procedure test_pr(IN param int)
begin
  select param;
end;

