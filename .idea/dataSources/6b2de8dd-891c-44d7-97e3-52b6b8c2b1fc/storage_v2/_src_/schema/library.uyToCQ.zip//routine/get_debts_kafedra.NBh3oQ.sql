create
  definer = root@localhost procedure get_debts_kafedra(IN f varchar(225))
BEGIN
    select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where students.faculty=f and students.debt > 10;
    select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where students.faculty=f and students.debt > 10;
    select DISTINCT(teachers.name) from books inner join teachers on books.reader_id = teachers.id where teachers.faculty=f and teachers.debt > 10;
    select count(DISTINCT(teachers.name)) from books inner join teachers on books.reader_id = teachers.id where teachers.faculty=f and teachers.debt > 10;
END;

