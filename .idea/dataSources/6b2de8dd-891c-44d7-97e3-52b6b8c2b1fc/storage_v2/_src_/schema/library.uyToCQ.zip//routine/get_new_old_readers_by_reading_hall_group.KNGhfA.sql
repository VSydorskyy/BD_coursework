create
  definer = root@localhost procedure get_new_old_readers_by_reading_hall_group(IN r_h int, IN gr int)
BEGIN
    select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where
                                                                                           books.read_hall = r_h and
                                                                                           students.group_num=gr and
                                                                                           year(students.join_date) = 2019;
  select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where
                                                                                             books.read_hall = r_h and
                                                                                             students.group_num=gr and
                                                                                             year(students.join_date) = 2019;
  select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where
                                                                                             books.read_hall = r_h and
                                                                                             students.group_num=gr and
                                                                                             year(students.left_date) = 2019;
  select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where
                                                                                             books.read_hall = r_h and
                                                                                             students.group_num=gr and
                                                                                             year(students.left_date) = 2019;
END;

