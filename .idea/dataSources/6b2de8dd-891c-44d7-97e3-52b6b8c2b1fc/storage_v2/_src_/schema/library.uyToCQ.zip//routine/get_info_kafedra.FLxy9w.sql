create
  definer = root@localhost procedure get_info_kafedra(IN f varchar(225))
BEGIN
    select * from books inner join students on books.reader_id = students.id where students.faculty=f;
    select * from books inner join teachers on books.reader_id = teachers.id where teachers.faculty=f;
END;

