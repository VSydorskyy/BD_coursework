create
  definer = root@localhost procedure get_debts_by_reading_hall_course(IN r_h int, IN cr int)
BEGIN
    select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where books.read_hall = r_h and students.course=cr and students.debt > 10;
    select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where books.read_hall = r_h and students.course=cr and students.debt > 10;
END;

