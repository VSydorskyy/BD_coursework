create
  definer = root@localhost procedure get_new_old_readers_kafedra(IN f varchar(225))
BEGIN
      select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where
                                                                                           students.faculty=f and
                                                                                           year(students.join_date) = 2019;
  select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where
                                                                                             students.faculty=f and
                                                                                             year(students.join_date) = 2019;
  select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where
                                                                                             students.faculty=f and
                                                                                             year(students.left_date) = 2019;
  select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where
                                                                                             students.faculty=f and
                                                                                             year(students.left_date) = 2019;
      select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where
                                                                                           students.faculty=f and
                                                                                           year(students.join_date) = 2019;
  select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where
                                                                                             students.faculty=f and
                                                                                             year(students.join_date) = 2019;
  select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where
                                                                                             students.faculty=f and
                                                                                             year(students.left_date) = 2019;
  select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where
                                                                                             students.faculty=f and
                                                                                             year(students.left_date) = 2019;
END;

