create
  definer = root@localhost procedure get_debts_by_reading_hall_group(IN r_h int, IN gr int)
BEGIN
    select * from books inner join students on books.reader_id = students.id where books.read_hall = r_h and students.faculty=gr and students.debt > 10;
    select count(*) from books inner join students on books.reader_id = students.id where books.read_hall = r_h and students.faculty=gr and students.debt > 10;
END;

