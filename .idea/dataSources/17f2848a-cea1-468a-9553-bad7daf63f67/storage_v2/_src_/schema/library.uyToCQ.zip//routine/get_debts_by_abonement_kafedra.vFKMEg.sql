create
  definer = root@localhost procedure get_debts_by_abonement_kafedra(IN a int, IN f varchar(225))
BEGIN
    select * from books inner join students on books.reader_id = students.id where books.abonement = a and students.faculty=f and students.debt > 10;
    select count(*) from books inner join students on books.reader_id = students.id where books.abonement = a and students.faculty=f and students.debt > 10;
    select * from books inner join teachers on books.reader_id = teachers.id where books.abonement = a and teachers.faculty=f and teachers.debt > 10;
    select count(*) from books inner join teachers on books.reader_id = teachers.id where books.abonement = a and teachers.faculty=f and teachers.debt > 10;
END;

