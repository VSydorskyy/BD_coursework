create
  definer = root@localhost procedure get_forbid_students_by_kafedra(IN f varchar(225))
BEGIN
    select * from students where students.faculty=f and students.forbid_date > 2;
    select count(*) from students where students.faculty=f and students.forbid_date > 2;
END;

