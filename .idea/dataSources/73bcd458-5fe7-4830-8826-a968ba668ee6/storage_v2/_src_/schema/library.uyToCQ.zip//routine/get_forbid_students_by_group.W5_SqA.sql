create
  definer = root@localhost procedure get_forbid_students_by_group(IN gr int)
BEGIN
    select * from students where students.group_num=gr and students.forbid_date > 2;
    select count(*) from students where students.group_num=gr and students.forbid_date > 2;
END;

