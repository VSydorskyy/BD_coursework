create
  definer = root@localhost procedure get_top_books_by_read_hall_faculty(IN r_h int, IN f varchar(225))
BEGIN
    select count(temp_table.id) as num_books, temp_table.name as book_name from
    (
        select teachers.id, teachers.faculty, books.name, books.read_hall
        from teachers
                 inner join books on teachers.id = books.reader_id
        union all
        select students.id, students.faculty, books.name, books.read_hall
        from students
                 inner join books on students.id = books.reader_id
    )temp_table
    where temp_table.read_hall = r_h and temp_table.faculty =f
    group by temp_table.name 
    ORDER BY num_books desc 
    limit 20;
END;

