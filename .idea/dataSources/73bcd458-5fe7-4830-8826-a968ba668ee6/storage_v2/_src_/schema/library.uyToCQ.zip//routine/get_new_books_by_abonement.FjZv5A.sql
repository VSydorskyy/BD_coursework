create
  definer = root@localhost procedure get_new_books_by_abonement(IN ab int, IN author varchar(225), IN release_year int)
BEGIN
        select books.name from books where
                                      books.abonement = ab and
                                      books.released = release_year and
                                      books.author = author and
                                      books.received = 2019;
END;

