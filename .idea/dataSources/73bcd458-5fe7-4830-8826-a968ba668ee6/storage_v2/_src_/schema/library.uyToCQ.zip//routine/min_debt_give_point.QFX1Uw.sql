create
  definer = root@localhost procedure min_debt_give_point()
begin
  select count(temp_table.give_point) as amount, temp_table.give_point from
    (
          select teachers.debt, books.give_point
          from teachers
                   inner join books on teachers.id = books.reader_id where teachers.debt > 0
          union all
          select students.debt , books.give_point
          from students
                   inner join books on students.id = books.reader_id where students.debt > 0
          union all
          select other_readers.debt, books.give_point
          from other_readers
                   inner join books on other_readers.id = books.reader_id where other_readers.debt > 0
    )temp_table
  group by temp_table.give_point order by amount limit 1;
end;

