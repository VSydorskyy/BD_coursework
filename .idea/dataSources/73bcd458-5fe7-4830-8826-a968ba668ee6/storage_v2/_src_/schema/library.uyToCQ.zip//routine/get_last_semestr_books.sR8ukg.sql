create
  definer = root@localhost procedure get_last_semestr_books()
begin
  select name from books where month(order_date) < 06;
  select count(name) from books where month(order_date) < 06;
end;

