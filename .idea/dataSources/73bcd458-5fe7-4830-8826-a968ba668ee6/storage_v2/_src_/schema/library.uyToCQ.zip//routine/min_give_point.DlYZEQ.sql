create
  definer = root@localhost procedure min_give_point()
begin
  select count(give_point) as amount, give_point from books group by give_point order by amount limit 1;
end;

