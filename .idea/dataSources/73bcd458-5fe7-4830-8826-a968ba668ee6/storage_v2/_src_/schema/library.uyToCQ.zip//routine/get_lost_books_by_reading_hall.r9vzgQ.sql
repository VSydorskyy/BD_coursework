create
  definer = root@localhost procedure get_lost_books_by_reading_hall(IN r_h int, IN author varchar(225),
                                                                    IN release_year int, IN receive_year int)
BEGIN
        select books.name from books where
                                      books.read_hall = r_h and
                                      books.released = release_year and
                                      books.received = receive_year and
                                      books.author = author and
                                      books.lost = 2019;
END;

