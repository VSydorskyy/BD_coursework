create
  definer = root@localhost procedure get_forbid_other_readers()
BEGIN
    select * from other_readers where other_readers.forbid_date > 2;
    select count(*) from other_readers where other_readers.forbid_date > 2;
END;

