create
  definer = root@localhost procedure get_readers_by_reading_hall(IN r_h int)
BEGIN
    select count(*) from books inner join students on books.reader_id = students.id where books.read_hall = r_h;
END;

