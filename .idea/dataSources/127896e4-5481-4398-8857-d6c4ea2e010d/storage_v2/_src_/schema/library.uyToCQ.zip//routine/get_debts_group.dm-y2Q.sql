create
  definer = root@localhost procedure get_debts_group(IN gr int)
BEGIN
    select * from books inner join students on books.reader_id = students.id where students.faculty=gr and students.debt > 10;
    select count(*) from books inner join students on books.reader_id = students.id where students.faculty=gr and students.debt > 10;
END;

