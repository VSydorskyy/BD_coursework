create
  definer = root@localhost procedure max_debt()
begin
  select max(temp_table.debt) from
    (
          select teachers.debt
          from teachers
          union all
          select students.debt
          from students
          union all
          select other_readers.debt
          from other_readers
    )temp_table;
end;

