create
  definer = root@localhost procedure test_procedure()
begin
  select * from teachers;
end;

