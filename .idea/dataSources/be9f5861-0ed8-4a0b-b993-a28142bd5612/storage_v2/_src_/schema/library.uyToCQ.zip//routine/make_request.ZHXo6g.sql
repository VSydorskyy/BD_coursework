create
  definer = root@localhost procedure make_request(IN request varchar(250))
begin

 SET @s := request;
 PREPARE dynamic_statement FROM @s;
 EXECUTE dynamic_statement;
 DEALLOCATE PREPARE dynamic_statement;

end;

