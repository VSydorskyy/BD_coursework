create
  definer = root@localhost procedure get_readers_by_reading_hall(IN test varchar(255))
BEGIN
    select * from books inner join students on books.reader_id = students.id;
END;

