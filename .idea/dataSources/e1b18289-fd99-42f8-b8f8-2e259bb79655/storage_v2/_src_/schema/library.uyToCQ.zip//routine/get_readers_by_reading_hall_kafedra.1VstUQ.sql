create
  definer = root@localhost procedure get_readers_by_reading_hall_kafedra(IN r_h int, IN f varchar(225))
BEGIN
    select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where books.read_hall = r_h and students.faculty=f;
    select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where books.read_hall = r_h and students.faculty=f;
    select DISTINCT(teachers.name) from books inner join teachers on books.reader_id = teachers.id where books.read_hall = r_h and teachers.faculty=f;
    select count(DISTINCT(teachers.name)) from books inner join teachers on books.reader_id = teachers.id where books.read_hall = r_h and teachers.faculty=f;
END;

