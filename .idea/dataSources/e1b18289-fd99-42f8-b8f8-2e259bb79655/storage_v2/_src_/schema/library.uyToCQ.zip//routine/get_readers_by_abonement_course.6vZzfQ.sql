create
  definer = root@localhost procedure get_readers_by_abonement_course(IN a int, IN cr int)
BEGIN
    select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where books.abonement = a and students.course=cr;
    select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where books.abonement = a and students.course=cr;
END;

