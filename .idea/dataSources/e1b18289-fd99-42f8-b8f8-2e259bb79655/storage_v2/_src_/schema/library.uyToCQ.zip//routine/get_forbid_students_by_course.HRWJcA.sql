create
  definer = root@localhost procedure get_forbid_students_by_course(IN cr int)
BEGIN
    select * from students where students.course=cr and students.forbid_date > 2;
    select count(*) from students where students.course=cr and students.forbid_date > 2;
END;

