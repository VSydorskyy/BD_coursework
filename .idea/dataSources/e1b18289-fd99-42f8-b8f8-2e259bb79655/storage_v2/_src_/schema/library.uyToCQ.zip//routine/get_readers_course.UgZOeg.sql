create
  definer = root@localhost procedure get_readers_course(IN cr int)
BEGIN
    select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where students.course=cr;
    select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where students.course=cr;
END;

