create
  definer = root@localhost procedure get_readers_by_abonement_kafedra(IN a int, IN f varchar(225))
BEGIN
    select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where books.abonement = a and students.faculty=f;
    select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where books.abonement = a and students.faculty=f;
    select DISTINCT(teachers.name) from books inner join teachers on books.reader_id = teachers.id where books.abonement = a and teachers.faculty=f;
    select count(DISTINCT(teachers.name)) from books inner join teachers on books.reader_id = teachers.id where books.abonement = a and teachers.faculty=f;
END;

