create
  definer = root@localhost procedure find_book(IN book_name varchar(255))
begin 
  select count(id) from books where abonement<>0 and name = book_name;
end;

