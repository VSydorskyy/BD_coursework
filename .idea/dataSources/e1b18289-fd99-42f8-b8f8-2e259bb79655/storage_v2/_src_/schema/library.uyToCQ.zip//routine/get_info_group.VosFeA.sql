create
  definer = root@localhost procedure get_info_group(IN gr int)
BEGIN
    select * from books inner join students on books.reader_id = students.id where students.group_num=gr;
END;

