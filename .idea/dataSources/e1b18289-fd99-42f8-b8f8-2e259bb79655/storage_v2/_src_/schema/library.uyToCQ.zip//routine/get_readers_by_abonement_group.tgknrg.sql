create
  definer = root@localhost procedure get_readers_by_abonement_group(IN a int, IN gr int)
BEGIN
    select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where books.abonement = a and students.group_num=gr;
    select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where books.abonement = a and students.group_num=gr;
END;

