create
  definer = root@localhost procedure get_new_books_by_reading_hall(IN r_h int, IN author varchar(225), IN release_year int)
BEGIN
        select books.name from books where
                                      books.read_hall = r_h and
                                      books.released = release_year and
                                      books.author = author and
                                      books.received = 2019;
END;

