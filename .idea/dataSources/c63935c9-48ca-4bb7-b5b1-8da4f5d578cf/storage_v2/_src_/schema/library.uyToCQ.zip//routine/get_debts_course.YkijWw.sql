create
  definer = root@localhost procedure get_debts_course(IN cr int)
BEGIN
    select * from books inner join students on books.reader_id = students.id where students.faculty=cr and students.debt > 10;
    select count(*) from books inner join students on books.reader_id = students.id where students.faculty=cr and students.debt > 10;
END;

