create
  definer = root@localhost procedure get_books_amount()
begin 
  select count(name) as amount_of_books, name from books group by name;
end;

