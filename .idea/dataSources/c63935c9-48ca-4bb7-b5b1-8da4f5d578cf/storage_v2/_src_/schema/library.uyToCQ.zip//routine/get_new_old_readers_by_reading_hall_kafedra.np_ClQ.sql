create
  definer = root@localhost procedure get_new_old_readers_by_reading_hall_kafedra(IN r_h int, IN f varchar(225))
BEGIN
  select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where
                                                                                             books.read_hall = r_h and
                                                                                             students.faculty=f and
                                                                                             year(students.join_date) = 2019;
  select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where
                                                                                             books.read_hall = r_h and
                                                                                             students.faculty=f and
                                                                                             year(students.join_date) = 2019;
  select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where
                                                                                             books.read_hall = r_h and
                                                                                             students.faculty=f and
                                                                                             year(students.left_date) = 2019;
  select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where
                                                                                             books.read_hall = r_h and
                                                                                             students.faculty=f and
                                                                                             year(students.left_date) = 2019;
  select DISTINCT(teachers.name) from books inner join teachers on books.reader_id = teachers.id where
                                                                                           books.read_hall = r_h and
                                                                                           teachers.faculty=f and
                                                                                           year(teachers.join_date) = 2019;
  select count(DISTINCT(teachers.name)) from books inner join teachers on books.reader_id = teachers.id where
                                                                                             books.read_hall = r_h and
                                                                                             teachers.faculty=f and
                                                                                             year(teachers.join_date) = 2019;
  select DISTINCT(teachers.name) from books inner join teachers on books.reader_id = teachers.id where
                                                                                             books.read_hall = r_h and
                                                                                             teachers.faculty=f and
                                                                                             year(teachers.left_date) = 2019;
  select count(DISTINCT(teachers.name)) from books inner join teachers on books.reader_id = teachers.id where
                                                                                             books.read_hall = r_h and
                                                                                             teachers.faculty=f and
                                                                                             year(teachers.left_date) = 2019;
END;

