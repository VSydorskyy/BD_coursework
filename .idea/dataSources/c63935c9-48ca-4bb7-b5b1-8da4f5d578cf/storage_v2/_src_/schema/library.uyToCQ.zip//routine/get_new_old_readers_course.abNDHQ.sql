create
  definer = root@localhost procedure get_new_old_readers_course(IN cr int)
BEGIN
      select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where
                                                                                           students.course=cr and
                                                                                           year(students.join_date) = 2019;
  select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where
                                                                                             students.course=cr and
                                                                                             year(students.join_date) = 2019;
  select DISTINCT(students.name) from books inner join students on books.reader_id = students.id where
                                                                                             students.course=cr and
                                                                                             year(students.left_date) = 2019;
  select count(DISTINCT(students.name)) from books inner join students on books.reader_id = students.id where
                                                                                             students.course=cr and
                                                                                             year(students.left_date) = 2019;
END;

