create
  definer = root@localhost procedure get_forbid_teachers_by_kafedra(IN f varchar(225))
BEGIN
    select * from teachers where teachers.faculty=f and teachers.forbid_date > 2;
    select count(*) from teachers where teachers.faculty=f and teachers.forbid_date > 2;
END;

