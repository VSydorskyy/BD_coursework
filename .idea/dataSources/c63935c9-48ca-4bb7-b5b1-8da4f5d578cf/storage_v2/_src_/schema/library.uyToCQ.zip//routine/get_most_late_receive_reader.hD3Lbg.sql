create
  definer = root@localhost procedure get_most_late_receive_reader()
begin 
  select temp_table.name from
      (
            select teachers.name, books.receive_date
            from teachers
                     inner join books on teachers.id = books.reader_id
            union all
            select students.name, books.receive_date
            from students
                     inner join books on students.id = books.reader_id
            union all
            select other_readers.name, books.receive_date
            from other_readers
                     inner join books on other_readers.id = books.reader_id
      )temp_table
  where year(temp_table.receive_date)<>1000 order by temp_table.receive_date limit 1;
end;

