create
  definer = root@localhost procedure get_readers_order_last_month(IN reader_id int)
BEGIN
select temp_table.name as book_name from
    (
          select teachers.id, books.name, books.order_date
          from teachers
                   inner join books on teachers.id = books.reader_id
          union all
          select students.id, books.name, books.order_date
          from students
                   inner join books on students.id = books.reader_id
          union all
          select other_readers.id, books.name, books.order_date
          from other_readers
                   inner join books on other_readers.id = books.reader_id
    )temp_table
where temp_table.id = reader_id and month(temp_table.order_date) = 05;
select count(temp_table.name) as book_name from
    (
          select teachers.id, books.name, books.order_date
          from teachers
                   inner join books on teachers.id = books.reader_id
          union all
          select students.id, books.name, books.order_date
          from students
                   inner join books on students.id = books.reader_id
          union all
          select other_readers.id, books.name, books.order_date
          from other_readers
                   inner join books on other_readers.id = books.reader_id
    )temp_table
where temp_table.id = reader_id and month(temp_table.order_date) = 05;
END;

