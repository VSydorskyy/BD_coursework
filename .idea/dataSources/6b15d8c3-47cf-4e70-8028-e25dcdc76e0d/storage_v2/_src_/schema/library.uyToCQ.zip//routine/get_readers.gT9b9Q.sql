create
  definer = root@localhost procedure get_readers(IN value_book_filter int, IN value_reader_filter varchar(225))
begin
  
  select books.name, count(books.name) as num_books from books
  left join teachers on teachers.id = books.reader_id
  left join students on books.reader_id = students.id
    where (students.faculty = value_reader_filter or teachers.faculty =value_reader_filter)
    and read_hall=value_book_filter group by books.name
      order by num_books limit 20;
      
end;

